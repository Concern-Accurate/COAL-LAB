#include <iostream>
#include <string>
using namespace std;

class Queue {
private:
    int front = 0, front1 = 0, front2 = 0, front3 = 0, front4 = 0;
    int rear = 0, rear1 = 0, rear2 = 0, rear3 = 0, rear4 = 0;
    char arr[10000], arr1[10000], arr2[10000], arr3[10000], arr4[10000];

public:
    void enqueue() {
        cout << "Enter the value to add to queue: ";
        cin >> arr[rear];
        rear++;
    }

    void dequeue() {
        if (front == rear) {
            cout << "The queue is empty\n";
        } else {
            cout << "The value removed is " << arr[front] << endl;
            front++;
        }
    }

    int top() {
        if (front == rear) {
            cout << "The queue is empty" << endl;
            return -1;
        } else {
            cout << "The value at the front of the queue is " << arr[front] << endl;
            return arr[front];
        }
    }

    void empty() {
        if (front == rear) {
            cout << "The queue is empty" << endl;
        } else {
            cout << "The queue exists" << endl;
        }
    }

    void display() {
        if (front == rear) {
            cout << "The queue is empty" << endl;
        } else {
            cout << "All the values in the queue are: " << endl;
            for (int i = front; i < rear; i++) {
                cout << arr[i] << endl;
            }
        }
    }

    void save(const string& x) {
        int a = 0;
        for (int i = 0; i < x.size(); i++) {
            if (x[i] == ' ') {
                a++;
                continue;
            }
            if (a == 0) {
                arr[rear++] = x[i];
            } else if (a == 1) {
                arr1[rear1++] = x[i];
            } else if (a == 2) {
                arr2[rear2++] = x[i];
            } else if (a == 3) {
                arr3[rear3++] = x[i];
            } else if (a == 4) {
                arr4[rear4++] = x[i];
            }
        }
        arr[rear] = '\0';
        arr1[rear1] = '\0';
        arr2[rear2] = '\0';
        arr3[rear3] = '\0';
        arr4[rear4] = '\0';
    }

    void conc() {
        for (int i = 0; i < rear1; i++) {
            arr[rear++] = arr1[front1++];
        }
        for (int i = 0; i < rear2; i++) {
            arr[rear++] = arr2[front2++];
        }
        for (int i = 0; i < rear3; i++) {
            arr[rear++] = arr3[front3++];
        }
        for (int i = 0; i < rear4; i++) {
            arr[rear++] = arr4[front4++];
        }
        arr[rear] = '\0';
        cout << "Concatenated String: " << arr << endl;
    }

    void disp() {
        cout << "Array 1: " << arr << endl;
        cout << "Array 2: " << arr1 << endl;
        cout << "Array 3: " << arr2 << endl;
        cout << "Array 4: " << arr3 << endl;
        cout << "Array 5: " << arr4 << endl;
    }
};

int main() {
    string ada = "Hello how are you doing";
    Queue que;
    que.save(ada);
    que.disp();
    que.conc();
}

